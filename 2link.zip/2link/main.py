from pyrogram import Client
from z import bot
Client("bot",bot_token=bot,api_id=1415407,api_hash="118d68f87563b5c3b2b4ef7c4149f3d4",workers = 25).run()
