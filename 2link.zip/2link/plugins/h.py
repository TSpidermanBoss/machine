from pyrogram import Client, filters
from pyrogram.errors import FloodWait
import time
from z import u
@Client.on_message(filters.command('reset') & filters.user(u))
async def forward(client, message):
 with open("ferrari.txt" , "w") as g:
  g.write("")
  g.close()
 with open("bullet.txt" , "w") as g:
  g.write("")
  g.close()
 await message.reply("🔥 Operation Completed 🙋")

