from pyrogram import Client, filters
from pyrogram.errors import FloodWait
import time
from z import u
@Client.on_message(filters.command("help"))
async def forward(client, message):
 if message.from_user.id == u:
   await message.reply("""♻️ Available Commands:

1. [ ```/add chat_id bullet/ferrari``` ] add a new chat id

2. [ ```/remove chat_id bullet/ferrari``` ] add a new chat id

3. [ ```/list bullet/ferrari``` ] get the list of chats

4. [ ```/get chat_id``` ] get chat information

5. [ ```/reset``` ] reset the bot

6. [ ```/clear``` ] use to for your bot become faster

🔥 For any information 

contact : @Cricket6 """)
 else:
   await message.reply("""♻️ Sorry but this bot not available for free 

🙋 Contact : @Cricket6 

to get premium plans ✅✅""")
