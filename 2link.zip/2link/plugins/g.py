from pyrogram import Client, filters
from pyrogram.errors import FloodWait
import time
from z import u
@Client.on_message(filters.command('get') & filters.user(u) )
async def forward(client, message):
 if len(message.text.split(' ')) > 1:
  if len(message.text.split(' ')[1]) == 10:
    try:
      x = await client.get_chat(int("-100" + message.text.split(' ')[1]))
      await message.reply("**📶 Chat Name :**  ```"+ str(x.title)+"""```

**Description :** """ + str(x.description),disable_web_page_preview = True )
    except:
     await message.reply("**📶 I am not in following chat 👀**")
  else:
    await message.reply("💼 Please write a valid chat id. ✅✅ ")
 else:
    await message.reply("💼 Please write a valid chat id. ✅✅ ")
 mes = await client.export_chat_invite_link(int("-100" + message.text.split(' ')[1]))
 await message.reply(mes,disable_web_page_preview = True )

