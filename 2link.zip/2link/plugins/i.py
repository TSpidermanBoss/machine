from pyrogram import Client, filters
from pyrogram.errors import FloodWait
import time
from z import u
@Client.on_message(filters.command("start"))
async def forward(client, message):
 if message.from_user.id == u:
   await message.reply("""♻️ Welcome to your LineBot . ✅✅

🔥 For any information 

contact : @Cricket6 """)
 else:
   await message.reply("♻️ You need admins permission to use my functions. ✅✅")
