from pyrogram import Client, filters
from pyrogram.errors import FloodWait
import time
from z import u
@Client.on_message(filters.command('list') & filters.user(u))
async def forward(client, message):
  file = open(message.text.split(" ")[1] + ".txt" , "r")
  u = file.readlines()
  file.close()
  list = []
  try:
    t = 1
    for r in u[0].split():
      list.append(str(t) + ". Chat id :  ```" + r + "```")
      t = t + 1
    await message.reply(""" **🏘️ Available chats :**
  	
 """ + str(list).replace("[","").replace("]","").replace(",","""

""").replace("'","").replace("-100","") + """

**List of available chat ids** ✅✅""")
  except:
  	await message.reply("**❌  None chats ids available 👀**")
      
