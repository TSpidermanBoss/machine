from pyrogram import Client, filters
import threading
from z import ferrari
def send(r,c,m):
    mes = c.send_message(int(r),"**" + m.text + "**")
    fie = open("mesid/" + str(r)+".txt","a")
    fie.write(" " + str(m.message_id) + " " + str(mes.message_id))
    fie.close()
@Client.on_message(filters.text & filters.chat(ferrari) & ~ filters.edited)
def main(c,m):
 file = open("ferrari.txt","r")
 lines = file.readlines()
 file.close()
 threads = []
 for r in lines[0].split():
  t = threading.Thread(target=send, args=[r,c,m])
  threads.append(t)
  t.start()