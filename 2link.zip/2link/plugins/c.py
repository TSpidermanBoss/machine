from pyrogram import Client, filters
from pyrogram.errors import FloodWait
import time
from z import u
@Client.on_message(filters.command('add') & filters.user(u) )
async def forward(client, message):
 if len(message.text.split(' ')) > 2:
  if len(message.text.split(' ')[1]) == 10:
   fie = open(message.text.split(" ")[2]+".txt","a")
   fie.write(" -100" + message.text.split(' ')[1])
   fie.close()
   with open("mesid/-100" + message.text.split(' ')[1]+".txt" , "w") as g:
     g.write("001 002")
     g.close()
   await message.reply( """💾 Done, 

The chat : ```""" + message.text.split(' ')[1] +"""```

🌐 Successfully added to my database. ✅✅""" )
  else:
    await message.reply("💼 Please write a valid chat id. ✅✅ ")
 else:
   await message.reply("💼 Please write a valid chat id. ✅✅ ")
   
   
    
