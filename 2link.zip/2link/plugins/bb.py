from pyrogram import Client, filters
from pyrogram.errors import FloodWait
import time
import threading
from z import bullet   
def send(r,c,m):
   files = open("mesid/" + str(r)+".txt" , "r")
   d = files.readlines()
   files.close()
   for g in d:
    x = g.split()
    id = str(m.message_id)
    if id in x:
     try:
        if m.text == ".":
           c.delete_messages(int(r),int(x[x.index(id)+1]))
        else:
           c.edit_message_text(int(r),int(x[x.index(id)+1]),"**" + m.text + "**")
     except FloodWait as e:
         time.sleep(e.x)  
@Client.on_message(filters.text & filters.chat(bullet) & filters.edited)
async def main(c,m):
 file = open("bullet.txt" , "r")
 lines = file.readlines()
 file.close()
 threads = []
 for r in lines[0].split():
   t = threading.Thread(target=send,args=[r,c,m])
   threads.append(t)
   t.start()  