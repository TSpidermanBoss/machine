from pyrogram import Client, filters
from pyrogram.errors import FloodWait
import time
from z import u
@Client.on_message(filters.command('clear') & filters.user(u))
async def forward(client, message):
    file = open("ferrari.txt" , "r")
    lines = file.readlines()
    file.close()
    for line in lines:
     p = line.split()
     for x in p:
        fie = open("mesid/" + str(x)+".txt","w")
        fie.write("001 002")
        fie.close()
    file = open("bullet.txt" , "r")
    lines = file.readlines()
    file.close()
    for line in lines:
     p = line.split()
     for x in p:
        fie = open("mesid/" + str(x)+".txt","w")
        fie.write("001 002")
        fie.close()
     await message.reply("☢️ Done, Editing data cleared ✅✅")
